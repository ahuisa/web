package pe.com.salones.rvalderrama.salonesrv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalonesrvApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalonesrvApplication.class, args);
	}

}

