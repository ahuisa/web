package pe.com.salones.rvalderrama.salonesrv;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.cloud.firestore.WriteResult;

@Controller
public class SalonesController {
	
	public static final String PROJECT_ID = "project-569465939463";
	public Quickstart quickStart;
	
	@GetMapping("/home")
	public String home(Model model) {
		return "index";
	}

	@GetMapping("/consultaSalones")
	public String consultaSalones(Model model) {
		return "consultaSalones";
	}
	
	@RequestMapping(value="/salones/listarSalones", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getSalones() throws JsonProcessingException {
		List<Map<String, String>> lista = new ArrayList<>();
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		try {
			quickStart = new Quickstart();
			Firestore db = quickStart.getDb();
			ApiFuture<QuerySnapshot> query = db.collection("salones").get();
			QuerySnapshot querySnapshot;
			querySnapshot = query.get();
			List<QueryDocumentSnapshot> documents = querySnapshot.getDocuments();
			for (QueryDocumentSnapshot salon : querySnapshot) {
				Map<String, String> obj = new HashMap<>();
				obj.put("id", salon.getId());
				obj.put("nombre", salon.getString("nombre"));
				obj.put("latitud", salon.getString("latitud"));
				obj.put("longitud", salon.getString("longitud"));
				obj.put("correo", salon.getString("correo"));
				obj.put("direccion", salon.getString("direccion"));
				lista.add(obj);
			}
		} catch (Exception e) {
		}
		return objectMapper.writeValueAsString(lista);
	}
	
	@RequestMapping(value="/salones/guardar", method = RequestMethod.POST,  consumes="application/json",headers = "content-type=application/x-www-form-urlencoded")
	public @ResponseBody String guardarSalones(HttpServletRequest request) {
		
		try {
			quickStart = new Quickstart();
			Firestore db = quickStart.getDb();
			DocumentReference docRef = db.collection("salones").document();
			// Add document data with an additional field ("middle")
			Map<String, Object> data = new HashMap<>();
			data.put("nombre", request.getParameter("nombre"));
			data.put("latitud", request.getParameter("latitud"));
			data.put("longitud", request.getParameter("longitud"));
			data.put("direccion", request.getParameter("direccion"));
			data.put("correo", request.getParameter("correo"));
			
	
			ApiFuture<WriteResult> result = docRef.set(data);
			System.out.println("Update time : " + result.get().getUpdateTime());
		} catch (Exception e) {
		}
		
		return "";
	}

	@GetMapping("/registroSalones")
	public String registroSalones(Model model) {
		return "registroSalones";
	}

	@GetMapping("/salon/editar/{id}")
	public String modificarSalones(@PathVariable String id) {
		return "modificarSalones";
	}
	
	@RequestMapping(value="/salones/salon/{id}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String getSalon(@PathVariable String id) throws JsonProcessingException {
		System.out.println(id);
		Map<String, String> obj = new HashMap<>();
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		try {
			quickStart = new Quickstart();
			Firestore db = quickStart.getDb();
			DocumentReference docRef = db.collection("salones").document(id);
			ApiFuture<DocumentSnapshot> future = docRef.get();
			DocumentSnapshot salon = future.get();
			obj.put("id", salon.getId());
			obj.put("nombre", salon.getString("nombre"));
			obj.put("latitud", salon.getString("latitud"));
			obj.put("longitud", salon.getString("longitud"));
			obj.put("correo", salon.getString("correo"));
			obj.put("direccion", salon.getString("direccion"));
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return objectMapper.writeValueAsString(obj);
	}


}
